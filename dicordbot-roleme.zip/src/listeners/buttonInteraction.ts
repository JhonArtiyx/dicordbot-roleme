import { Events, Listener } from '@sapphire/framework';
import {
  Interaction,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  type ModalActionRowComponentBuilder,
} from 'discord.js';
import { getPrismaClient } from '../lib/prisma';

const prisma = getPrismaClient();

/**
 * Button Interaction Listener
 * Handles button clicks and shows verification modal
 */
export class ButtonInteractionListener extends Listener<typeof Events.InteractionCreate> {
  public constructor(context: Listener.LoaderContext, options: Listener.Options) {
    super(context, { ...options, event: Events.InteractionCreate });
  }

  public async run(interaction: Interaction) {
    // Only handle button interactions
    if (!interaction.isButton()) return;

    // Handle verify button
    if (interaction.customId === 'verifyButton') {
      await this.handleVerifyButton(interaction);
    }
  }

  /**
   * Creates and shows the verification modal
   */
  private async handleVerifyButton(interaction: any) {
    try {
      if (!interaction.guild) {
        await interaction.reply({
          content: '❌ This command can only be used in a server.',
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      // Get verification config
      let config = await prisma.verificationConfig.findUnique({
        where: { guildId: interaction.guild.id },
      });

      if (!config) {
        // Create default config
        config = await prisma.verificationConfig.create({
          data: {
            guildId: interaction.guild.id,
          },
        });
      }

      // Create modal
      const modal = new ModalBuilder()
        .setCustomId('verifyModal')
        .setTitle('Server Verification')
        .addComponents(
          new ActionRowBuilder<ModalActionRowComponentBuilder>().addComponents(
            new TextInputBuilder()
              .setCustomId('verifyQuestion')
              .setLabel(config.question)
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('Enter your answer...')
              .setRequired(true)
              .setMaxLength(50)
          )
        );

      // Show modal to user
      await interaction.showModal(modal);
    } catch (error) {
      console.error('Error showing verification modal:', error);
      await interaction.reply({
        content: '❌ An error occurred while opening verification. Please try again.',
        flags: MessageFlags.Ephemeral,
      });
    }
  }
}
