import { Events, Listener } from '@sapphire/framework';
import { Interaction, EmbedBuilder, MessageFlags, type ModalSubmitInteraction } from 'discord.js';
import { getPrismaClient } from '../lib/prisma';

const prisma = getPrismaClient();

/**
 * Modal Interaction Listener
 * Validates verification answers and assigns verified role
 */
export class ModalInteractionListener extends Listener<typeof Events.InteractionCreate> {
  public constructor(context: Listener.LoaderContext, options: Listener.Options) {
    super(context, { ...options, event: Events.InteractionCreate });
  }

  public async run(interaction: Interaction) {
    // Only handle modal submissions
    if (!interaction.isModalSubmit()) return;

    // Handle verify modal
    if (interaction.customId === 'verifyModal') {
      await this.handleVerifyModal(interaction as ModalSubmitInteraction<'cached'>);
    }
  }

  /**
   * Validates user answer and assigns verified role if correct
   */
  private async handleVerifyModal(interaction: ModalSubmitInteraction<'cached'>) {
    try {
      if (!interaction.guild) {
        await interaction.reply({
          content: '❌ This command can only be used in a server.',
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      // Get verification config
      let config = await prisma.verificationConfig.findUnique({
        where: { guildId: interaction.guild.id },
      });

      if (!config) {
        // Create default config if it doesn't exist
        config = await prisma.verificationConfig.create({
          data: {
            guildId: interaction.guild.id,
          },
        });
      }

      // Get user answer from modal
      const userAnswer = interaction.fields
        .getTextInputValue('verifyQuestion')
        .toLowerCase()
        .trim();

      // Check if answer is correct
      const isCorrect = config.answers.some(answer => answer.toLowerCase() === userAnswer);

      if (isCorrect) {
        // Get the verified role from config or find by name
        let verifiedRole = config.roleId
          ? interaction.guild?.roles.cache.get(config.roleId)
          : interaction.guild?.roles.cache.find(role => role.name.toLowerCase() === 'verified');

        // If role exists, assign it to user
        if (verifiedRole) {
          await interaction.member?.roles.add(verifiedRole);
        } else if (config.roleId) {
          console.warn(
            `Configured verification role ${config.roleId} not found in guild ${interaction.guild.id}`
          );
        }

        // Create success embed
        const successEmbed = new EmbedBuilder()
          .setColor('#00ff00')
          .setTitle('✅ Verification Successful')
          .setDescription(
            'You have been successfully verified!\n\n' +
              (verifiedRole ? `You have been given the ${verifiedRole} role.\n\n` : '') +
              'Welcome to the community!'
          )
          .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
          .setTimestamp();

        // Reply with success message (ephemeral - only visible to user)
        await interaction.reply({ embeds: [successEmbed], flags: MessageFlags.Ephemeral });
      } else {
        // Create failure embed
        const failEmbed = new EmbedBuilder()
          .setColor('#ff0000')
          .setTitle('❌ Verification Failed')
          .setDescription(
            'Your answer is incorrect.\n\n' +
              'Please try again by clicking the verification button.'
          )
          .setTimestamp();

        // Reply with failure message (ephemeral - only visible to user)
        await interaction.reply({ embeds: [failEmbed], flags: MessageFlags.Ephemeral });
      }
    } catch (error) {
      console.error('Error processing verification:', error);
      await interaction.reply({
        content: '❌ An error occurred while processing your verification. Please try again.',
        flags: MessageFlags.Ephemeral,
      });
    }
  }
}
