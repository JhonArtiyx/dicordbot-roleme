# Discord Bot - Role Me

Un bot de Discord construido con **Sapphire**, **Bun**, **Prisma**, **TypeScript**, **ESLint** y **Prettier**.

## 📋 Requisitos

- [Bun](https://bun.sh) (runtime)
- Node.js 18+ (para Prisma)
- Una base de datos PostgreSQL

## 🚀 Instalación

1. Instala las dependencias con Bun:

```bash
bun install
```

2. Configura las variables de entorno en `.env.local`:

```env
DISCORD_TOKEN=tu_token_aqui
CLIENT_ID=tu_client_id
GUILD_ID=tu_guild_id              # Guild ID para desarrollo (comandos instantáneos)
OWNER_IDS=tu_owner_id
DATABASE_URL=tu_database_url
NODE_ENV=development               # 'development' = comandos de guild, 'production' = comandos globales
LOG_LEVEL=debug
```

> **Nota:** En desarrollo (`NODE_ENV=development`), los comandos slash se registran automáticamente como comandos de guild para actualizaciones instantáneas. En producción (`NODE_ENV=production`), se usan comandos globales que tardan hasta 1 hora en sincronizarse.

3. Genera el cliente de Prisma:

```bash
bun prisma:generate
```

4. Crea las tablas en la base de datos:

```bash
bun prisma:migrate
```

> **Nota:** Se crearán las tablas `auto_roles` y `reaction_roles` automáticamente.

## 📝 Scripts Disponibles

- `bun dev` - Ejecuta el bot en modo desarrollo con watch
- `bun start` - Inicia el bot
- `bun build` - Compila TypeScript
- `bun lint` - Ejecuta ESLint
- `bun lint:fix` - Corrige problemas de ESLint automáticamente
- `bun format` - Formatea el código con Prettier
- `bun prisma:generate` - Genera el cliente de Prisma
- `bun prisma:migrate` - Crea una nueva migración
- `bun prisma:studio` - Abre Prisma Studio

## 📚 Estructura del Proyecto

```
.
├── src/
│   ├── index.ts                     # Punto de entrada del bot
│   ├── commands/                    # Comandos slash del bot
│   │   ├── ping.ts                  # Comando ping de ejemplo
│   │   ├── verify-setup.ts          # Setup de verificación (Admin)
│   │   ├── verify-config.ts         # Configuración de verificación (Admin)
│   │   ├── autorole.ts              # Gestión de auto roles (Admin)
│   │   └── reactionrole.ts          # Gestión de reaction roles (Admin)
│   ├── listeners/                   # Event listeners
│   │   ├── ready.ts                 # Bot ready event
│   │   ├── mentionPrefixOnly.ts     # Mention prefix handler
│   │   ├── buttonInteraction.ts     # Click en botón de verificación
│   │   ├── modalInteraction.ts      # Validación de respuestas
│   │   ├── guildMemberAdd.ts        # Welcome message + auto roles
│   │   ├── messageReactionAdd.ts    # Agregar rol por reacción
│   │   ├── messageReactionRemove.ts # Remover rol por reacción
│   │   └── commands/                # Command listeners
│   ├── lib/
│   │   ├── constants.ts             # Constantes del bot
│   │   ├── setup.ts                 # Configuración inicial
│   │   ├── utils.ts                 # Funciones utilitarias
│   │   └── prisma.ts                # Cliente de Prisma (singleton)
│   └── generated/
│       └── prisma/                  # Cliente de Prisma generado
├── prisma/
│   ├── schema.prisma                # Schema de Prisma
│   └── migrations/                  # Migraciones de la BD
├── package.json                     # Dependencias
├── tsconfig.json                    # Configuración de TypeScript
├── .eslintrc.json                   # Configuración de ESLint
├── .prettierrc.json                 # Configuración de Prettier
├── .prettierignore                  # Exclusiones de formato
└── .env.local                       # Variables de entorno
```

## 🤖 Comandos Disponibles

### `/ping`
Verifica la latencia del bot y la API de Discord.

```
User: /ping
Bot: Pong 🏓! (Round trip took: 45ms. Heartbeat: 120ms.)
```

### Sistema de Verificación

#### `/verify-setup` (Admin)
Envía un mensaje persistente con un botón de verificación al canal actual.

**Características:**
- Solo administradores pueden ejecutarlo
- El botón permanece funcional incluso después de reiniciar el bot
- Al hacer clic, muestra un modal con una pregunta de verificación
- Respuestas correctas otorgan el rol "Verified"

#### `/verify-config` (Admin)
Configura el sistema de verificación.

**Opciones:**
- `action: view` - Ver configuración actual
- `action: difficulty` - Cambiar dificultad (easy, medium, hard)
- `action: role` - Configurar el rol que se asigna al verificarse

**Ejemplos:**
```
# Ver configuración actual
/verify-config action:view

# Cambiar dificultad
/verify-config action:difficulty difficulty:easy

# Configurar rol de verificación
/verify-config action:role role:@Verified
```

### Sistema de Auto Roles

#### `/autorole add` (Admin)
Agrega un rol que se asignará automáticamente a nuevos miembros.

**Uso:**
```
/autorole add role:@Member
```

#### `/autorole remove` (Admin)
Remueve un rol de la lista de auto roles.

**Uso:**
```
/autorole remove role:@Member
```

#### `/autorole list` (Admin)
Muestra todos los roles configurados para asignación automática.

### Sistema de Reaction Roles

#### `/reactionrole create` (Admin)
Crea un nuevo panel de reaction roles.

**Parámetros:**
- `title`: Título del panel
- `description`: Descripción
- `mode`: `SINGLE` (un solo rol) o `MULTIPLE` (múltiples roles)

**Ejemplo:**
```
/reactionrole create 
  title:"Elige tus roles" 
  description:"Reacciona para obtener roles" 
  mode:MULTIPLE
```

#### `/reactionrole add` (Admin)
Agrega un reaction role a un mensaje existente.

**Parámetros:**
- `message_id`: ID del mensaje
- `emoji`: Emoji a usar (Unicode o custom)
- `role`: Rol a asignar
- `description`: (Opcional) Descripción del rol

**Ejemplo:**
```
/reactionrole add 
  message_id:1234567890 
  emoji:🎮 
  role:@Gamer 
  description:"Para jugadores"
```

#### `/reactionrole remove` (Admin)
Remueve un reaction role de un mensaje.

**Ejemplo:**
```
/reactionrole remove message_id:1234567890 emoji:🎮
```

#### `/reactionrole mode` (Admin)
Cambia el modo de un mensaje (SINGLE/MULTIPLE).

**Ejemplo:**
```
/reactionrole mode message_id:1234567890 mode:SINGLE
```

#### `/reactionrole list` (Admin)
Muestra todos los reaction roles configurados en el servidor.

## 🔐 Sistemas Implementados

### 1. Sistema de Verificación
El bot incluye un sistema completo de verificación de usuarios:

- **Welcome Message**: Saluda nuevos miembros automáticamente
- **Button Verification**: Botón persistente para iniciar verificación
- **Modal Interaction**: Pregunta de seguridad en un formulario modal
- **Role Assignment**: Asigna rol configurado tras respuesta correcta
- **Configurable**: Pregunta, respuestas y rol personalizables por servidor
- **Anti-Bot Protection**: Previene que bots automatizados se unan

**Configuración:**
1. Crea un rol para usuarios verificados (ej: "Verified", "Member")
2. Configura el rol: `/verify-config action:role role:@Verified`
3. (Opcional) Cambia la dificultad: `/verify-config action:difficulty difficulty:easy`
4. Envía el mensaje de verificación: `/verify-setup` en el canal deseado

> **Nota:** Si no configuras un rol, el bot buscará automáticamente un rol llamado "Verified".

### 2. Sistema de Auto Roles
Los auto roles se asignan automáticamente cuando un usuario se une al servidor:

- **Configuración Simple**: Usa `/autorole add` para agregar roles
- **Múltiples Roles**: Puedes configurar varios roles simultáneamente
- **Gestión Flexible**: Agrega o remueve roles fácilmente
- **Asignación Automática**: Los roles se asignan al momento de unirse

**Casos de uso:**
- Rol "Member" para todos los usuarios nuevos
- Rol "Unverified" hasta completar verificación
- Roles de bienvenida o tutoriales

### 3. Sistema de Reaction Roles
Los reaction roles permiten a los usuarios auto-asignarse roles mediante reacciones:

**Características:**
- **Modo Single**: Usuarios solo pueden tener un rol del panel
  - Al seleccionar uno nuevo, se remueve el anterior automáticamente
  - Útil para roles mutuamente exclusivos (equipos, rangos)
  
- **Modo Multiple**: Usuarios pueden tener varios roles del panel
  - Acumulación de roles según intereses
  - Útil para roles de notificaciones, juegos, etc.

- **Persistencia**: Los reaction roles funcionan incluso después de reiniciar el bot

- **Gestión Dinámica**: Agrega o remueve roles en tiempo real

- **Auto-Cleanup**: Remover la reacción remueve el rol automáticamente

**Casos de uso:**
- Selección de colores (modo SINGLE)
- Roles de notificaciones (modo MULTIPLE)
- Selección de juegos (modo MULTIPLE)
- Pronombres (modo MULTIPLE)
- Equipos o facciones (modo SINGLE)

## ⚡ Desarrollo vs Producción

### Desarrollo (`NODE_ENV=development`)
- **Comandos instantáneos**: Los slash commands se actualizan inmediatamente
- **Guild Commands**: Solo visibles en el servidor especificado en `GUILD_ID`
- **Ideal para testing**: Prueba cambios sin esperar la cache de Discord

### Producción (`NODE_ENV=production`)  
- **Comandos globales**: Disponibles en todos los servidores donde esté el bot
- **Cache de Discord**: Puede tardar hasta 1 hora en actualizar
- **Mejor rendimiento**: Discord cachea los comandos para respuestas más rápidas

**¿Cómo funciona?** El bot detecta automáticamente el entorno mediante `NODE_ENV` y registra los comandos en consecuencia. No necesitas cambiar código, solo la variable de entorno.

## 📖 Documentación

- [Sapphire Framework](https://sapphirejs.dev/)
- [Discord.js](https://discord.js.org/)
- [Prisma ORM](https://www.prisma.io/)
- [Bun](https://bun.sh)

## 📄 Licencia

MIT
