# Deployment Guide for Wispbyte

## Prerequisites

Before deploying to Wispbyte, ensure you have:

1. **Discord Bot Token** - Get it from [Discord Developer Portal](https://discord.com/developers/applications)
2. **PostgreSQL Database** - Your Prisma database URL (already configured at db.prisma.io)
3. **Wispbyte Account** - Sign up at [Wispbyte](https://wispbyte.com)

## Environment Variables

Configure these environment variables in Wispbyte's panel:

```env
DISCORD_TOKEN=your_discord_bot_token_here
DATABASE_URL=your_postgresql_connection_string_here
NODE_ENV=production
GUILD_ID=your_guild_id_for_testing_optional
```

## Deployment Steps

### 1. Create Server on Wispbyte

1. Go to [Create Server](https://wispbyte.com/client/create)
2. Fill in the required information:
   - **Server Name**: `discord-bot-roleme` (or your preferred name)
   - **Description**: Discord bot with role management features
   - **Docker Image**: Select **Bun** or **Node.js 20+** (Bun preferred)

### 2. Deploy Your Code

Wispbyte typically supports Git integration:

1. Push your code to GitHub/GitLab
2. Connect your repository in Wispbyte
3. Wispbyte will automatically detect the `Dockerfile` and build

**OR** if using manual deployment:

1. Upload your project files via Wispbyte's file manager
2. Ensure `Dockerfile` is in the root directory
3. Trigger a build in the panel

### 3. Configure Environment Variables

In Wispbyte panel:
1. Navigate to **Environment Variables** section
2. Add each variable from the list above
3. Save changes

### 4. Database Migration

**Important**: Run Prisma migrations before starting the bot:

If Wispbyte provides a terminal/console access:
```bash
bun prisma migrate deploy
```

Or add this to your start script (package.json):
```json
"start": "bun prisma migrate deploy && bun src/index.ts"
```

### 5. Start the Bot

1. Click **Start** in Wispbyte panel
2. Monitor logs to verify successful connection
3. Look for: `✅ Bot logged in as YourBotName#1234`

## Docker Commands (Local Testing)

Test the Docker image locally before deploying:

```bash
# Build the image
docker build -t discord-bot-roleme .

# Run the container
docker run -d \
  --name discord-bot \
  -e DISCORD_TOKEN=your_token \
  -e DATABASE_URL=your_db_url \
  -e NODE_ENV=production \
  discord-bot-roleme

# View logs
docker logs -f discord-bot

# Stop container
docker stop discord-bot
```

## Troubleshooting

### Bot doesn't start
- Check environment variables are set correctly
- Verify DISCORD_TOKEN is valid
- Check DATABASE_URL connection

### Database connection errors
- Ensure DATABASE_URL is correct
- Run `bun prisma migrate deploy` manually
- Check if database is accessible from Wispbyte servers

### Missing commands
- Verify bot has proper intents enabled in Discord Developer Portal
- Check if commands are registered (check logs)
- Try removing and re-inviting the bot

## Resource Requirements

Recommended Wispbyte plan:
- **RAM**: 256 MB minimum (512 MB recommended)
- **CPU**: 0.25 vCPU minimum
- **Storage**: 500 MB

## Support

For Wispbyte-specific issues:
- Read [Terms of Service](https://wispbyte.com/terms)
- Review [Fair Use Policy](https://wispbyte.com/fair-use)
- Contact Wispbyte support

For bot issues:
- Check bot logs in Wispbyte panel
- Review Discord.js and Sapphire documentation
